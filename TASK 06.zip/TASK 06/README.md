
# Task 6: Sales Trend Analysis

## Objective
Analyze monthly revenue and order volume using SQL aggregation techniques.

## SQL Features Used
- EXTRACT()
- GROUP BY
- SUM()
- COUNT(DISTINCT)
- ORDER BY
- LIMIT

## Files Included
- `sales_trend_analysis.sql`: SQL queries for the analysis
- `results_table.csv`: Monthly revenue and order volume
- `top_3_months.csv`: Top 3 months by total revenue

## Summary
This task uses SQL to analyze time-based sales trends. It calculates monthly revenue and order count, then identifies the top 3 months based on revenue using aggregate functions and sorting.
